module Vtk.Types.Common
  ( VtkVal (..)
  ) where

import Data.Word

data VtkVal f =
  VtkDouble (f Double) |
  VtkWord (f Word8)

instance Show (VtkVal f) where
  show (VtkDouble _) = "VtkDouble"
  show (VtkWord _) = "VtkWord"
