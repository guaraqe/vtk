module Vtk.Types.StructuredPoints
  ( StructuredPoints (..)
  )where

import Vtk.Types.Common
import Linear.V3

data StructuredPoints f = StructuredPoints
  { sp_dimensions :: V3 Int
  , sp_origin :: V3 Double
  , sp_spacing :: V3 Double
  , sp_points :: VtkVal f
  } deriving Show
