{-# LANGUAGE StrictData #-}

module Vtk.Types
  ( Vtk (..)
  , VtkType (..)
  , VtkData (..)
  , StructuredPoints (..)
  , getWord
  , module Types
  ) where

import Vtk.Types.Common as Types
import Vtk.Types.StructuredPoints as Types

import Data.Word

data VtkType = VtkAscii | VtkBinary
  deriving (Show, Eq)

data Vtk f = Vtk
  { vtk_version :: (Int,Int)
  , vtk_title :: String
  , vtk_type :: VtkType
  , vtk_data :: VtkData f
  } deriving Show

getWord :: Vtk f -> Maybe (f Word8)
getWord (Vtk _ _ _ (VtkStructuredPoints (StructuredPoints _ _ _ val))) =
  case val of
    VtkDouble _ -> Nothing
    VtkWord x -> Just x

--------------------------------------------------------------------------------

data VtkData f =
  VtkStructuredPoints (StructuredPoints f)
  deriving Show
