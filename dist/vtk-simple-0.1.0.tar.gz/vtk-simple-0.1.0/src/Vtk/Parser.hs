{-# LANGUAGE OverloadedStrings #-}

module Vtk.Parser
  ( vtkParser
  ) where

import Vtk.Types

import Vtk.Parser.Common
import Vtk.Parser.StructuredPoints

import Data.Attoparsec.ByteString
import qualified Data.Attoparsec.ByteString.Char8 as Char

import qualified Data.Vector.Storable as V

--------------------------------------------------------------------------------

parseVersion :: Parser (Int,Int)
parseVersion = do
  _ <- string "# vtk DataFile Version "
  n1 <- Char.decimal
  _ <- string "."
  n2 <- Char.decimal
  Char.endOfLine
  return (n1,n2)

parseTitle :: Parser String
parseTitle = do
  _ <- string "# "
  s <- toEOL
  return s

parseType :: Parser VtkType
parseType = do
  s <- toEOL
  case s of
    "ASCII" -> return VtkAscii
    "BINARY" -> return VtkBinary
    _ -> fail "VtkType parser failed"

parseVtkData :: Parser (VtkData V.Vector)
parseVtkData = do
  _ <- string "DATASET "
  s <- toEOL
  case s of
    "STRUCTURED_POINTS" -> VtkStructuredPoints <$> structuredPoints
    _ -> fail "non supported type"

vtkParser :: Parser (Vtk V.Vector)
vtkParser =
  Vtk <$>
    parseVersion <*>
    parseTitle <*>
    parseType <*>
    parseVtkData
