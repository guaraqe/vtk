module Vtk
  ( vtkParser
  , module Types
  , test
  ) where

import Vtk.Parser

import Vtk.Types as Types

import Data.Attoparsec.ByteString

import qualified Data.ByteString as B
import qualified Data.Vector.Storable as V

test :: FilePath -> IO (Vtk V.Vector)
test path = do
  file <- B.readFile path
  case eitherResult $ parse vtkParser file of
     Left e -> fail e
     Right r -> return r
